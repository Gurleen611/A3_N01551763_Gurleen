const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const Image = require('../models/image');
const router = express.Router();

// Multer setup
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Upload multiple files
router.post('/multiple', upload.array('files', 100), (req, res) => {
  if (!req.files || req.files.length === 0) {
    return res.status(400).send('No files uploaded.');
  }

  const imagePromises = req.files.map((file) => {
    return sharp(file.buffer)
      .resize({ width: 500 })
      .toBuffer()
      .then((thumbnail) => {
        const newImage = new Image({
          filename: file.originalname,
          contentType: file.mimetype,
          imageBuffer: file.buffer,
          imageBufferThumbnail: thumbnail,
        });

        return newImage.save();
      })
      .catch((error) => {
        console.error('Error processing file:', error);
        throw error;
      });
  });

  Promise.all(imagePromises)
    .then(() => res.status(200).send('Files uploaded successfully.'))
    .catch((error) => res.status(500).send('Error saving files to database.'));
});

module.exports = router;

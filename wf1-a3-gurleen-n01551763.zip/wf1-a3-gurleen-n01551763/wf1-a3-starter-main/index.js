const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
require('dotenv').config();
const app = express();

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });
const db = mongoose.connection;
db.once("open", () => console.log("Connected to MongoDB"));
db.on("error", (err) => console.error("DB Error:", err));

// Middleware
app.use(express.static(path.join(__dirname, 'views')));

// Routes
app.get("/fetch-random", (req, res) => {
  res.sendFile(path.join(__dirname, "/views/fetch-random.html"));
});
app.get("/fetch-multiple-random", (req, res) => {
  res.sendFile(path.join(__dirname, "/views/fetch-multiple-random.html"));
});

// Set up other routes
app.listen(3000, () => console.log('Server running on port 3000'));
